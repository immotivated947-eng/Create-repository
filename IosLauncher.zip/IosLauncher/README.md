# iOS-style Android Launcher

A small Kotlin launcher with an iOS look: rounded-square icons, frosted dock and widget,
page dots, a clock widget, a search pill, and long-press for App Info / Remove App.

## Build
1. Open this folder in Android Studio (Ladybug or newer) and let Gradle sync.
2. Run on your phone (USB debugging on) or build an APK: Build > Build APK(s).
3. Press Home. Android will ask which home app to use. Pick "iOS Launcher" and choose Always.
   Or go to Settings > Apps > Default apps > Home app.

## Notes
- Needs Android 8.0+ (minSdk 26).
- The wallpaper is your normal system wallpaper.
- No real background blur. The frosted look is translucent fills with a thin border.
- The dock uses your default Phone, Messages, Browser and Camera apps.
- Tweak sizes and colors in MainActivity.kt (search for `glass(` and `60.dp`).
