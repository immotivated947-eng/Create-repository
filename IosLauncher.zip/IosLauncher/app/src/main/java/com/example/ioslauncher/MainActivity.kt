package com.example.ioslauncher

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.concurrent.thread

class AppEntry(val label: String, val pkg: String, val intent: Intent, val icon: Drawable)

class MainActivity : ComponentActivity() {

    private companion object {
        const val COLS = 4
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var dots: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var overlay: LinearLayout
    private lateinit var searchField: EditText
    private lateinit var results: LinearLayout

    private var allApps: List<AppEntry> = emptyList()
    private var pages: List<List<AppEntry>> = emptyList()

    private val dockIntents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
    )

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        buildUi()
        reload()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        onBackPressedDispatcher.addCallback(this) {
            if (overlay.visibility == View.VISIBLE) closeSearch() else pager.setCurrentItem(0, true)
        }
        addOnNewIntentListener {
            closeSearch()
            pager.setCurrentItem(0, true)
        }
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun buildUi() {
        root = FrameLayout(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        pager = ViewPager2(this).apply {
            adapter = PageAdapter()
            (getChildAt(0) as? RecyclerView)?.overScrollMode = View.OVER_SCROLL_NEVER
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) = updateDots(position)
            })
        }
        content.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        content.addView(dots, LinearLayout.LayoutParams(MATCH, 22.dp))

        val magnifier = ContextCompat.getDrawable(this, android.R.drawable.ic_menu_search)!!
            .mutate().apply { setTint(Color.argb(210, 255, 255, 255)) }
        val pill = TextView(this).apply {
            text = "Search"
            textSize = 14f
            setTextColor(Color.argb(210, 255, 255, 255))
            gravity = Gravity.CENTER
            compoundDrawablePadding = 8.dp
            setCompoundDrawablesWithIntrinsicBounds(magnifier, null, null, null)
            setPadding(22.dp, 0, 22.dp, 0)
            background = glass(18, Color.argb(56, 255, 255, 255))
            setOnClickListener { openSearch() }
        }
        content.addView(pill, LinearLayout.LayoutParams(WRAP, 36.dp).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = 12.dp
        })

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glass(34, Color.argb(72, 255, 255, 255))
            setPadding(12.dp, 12.dp, 12.dp, 12.dp)
        }
        content.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(16.dp, 0, 16.dp, 8.dp)
        })

        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(Color.argb(215, 0, 0, 0))
            setOnClickListener { closeSearch() }
        }
        searchField = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Color.argb(140, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 17f
            isSingleLine = true
            background = glass(14, Color.argb(56, 255, 255, 255))
            setPadding(16.dp, 12.dp, 16.dp, 12.dp)
            doAfterTextChanged { showResults(it?.toString().orEmpty()) }
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        overlay.addView(searchField, LinearLayout.LayoutParams(MATCH, WRAP))
        overlay.addView(
            ScrollView(this).apply { addView(results) },
            LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = 12.dp }
        )

        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            content.setPadding(0, bars.top, 0, bars.bottom)
            overlay.setPadding(16.dp, bars.top + 16.dp, 16.dp, maxOf(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun glass(radiusDp: Int, fill: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radiusDp.dp.toFloat()
        setStroke(1.dp, Color.argb(60, 255, 255, 255))
    }

    private fun rowsPerPage(): Int {
        val heightDp = resources.displayMetrics.heightPixels / resources.displayMetrics.density
        return ((heightDp - 260) / 100).toInt().coerceIn(3, 6)
    }

    private fun rebuildDots() {
        dots.removeAllViews()
        repeat(pages.size) {
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.WHITE)
                }
            }
            dots.addView(dot, LinearLayout.LayoutParams(7.dp, 7.dp).apply { setMargins(4.dp, 0, 4.dp, 0) })
        }
        updateDots(pager.currentItem)
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) dots.getChildAt(i).alpha = if (i == selected) 1f else 0.35f
    }

    // ---------- Pages ----------

    private inner class PageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = pages.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val frame = FrameLayout(parent.context).apply { layoutParams = ViewGroup.LayoutParams(MATCH, MATCH) }
            return object : RecyclerView.ViewHolder(frame) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val frame = holder.itemView as FrameLayout
            frame.removeAllViews()
            frame.addView(buildPage(pages[position], position == 0))
        }
    }

    private fun buildPage(apps: List<AppEntry>, withWidget: Boolean): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14.dp, 12.dp, 14.dp, 0)
        }
        if (withWidget) page.addView(clockWidget(), LinearLayout.LayoutParams(MATCH, 150.dp))
        apps.chunked(COLS).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until COLS) {
                val v: View = rowApps.getOrNull(i)?.let { cell(it) } ?: Space(this)
                row.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            page.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 16.dp })
        }
        return page
    }

    private fun clockWidget(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(26, Color.argb(56, 255, 255, 255))
            setPadding(22.dp, 0, 22.dp, 0)
        }
        card.addView(TextClock(this).apply {
            format12Hour = "EEEE, MMM d"
            format24Hour = "EEEE, MMM d"
            setTextColor(Color.argb(210, 255, 255, 255))
            textSize = 15f
        })
        card.addView(TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "H:mm"
            setTextColor(Color.WHITE)
            textSize = 58f
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        return card
    }

    // ---------- Icons ----------

    private fun cell(app: AppEntry, showLabel: Boolean = true): View {
        val size = 60.dp
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        col.addView(iconView(app.icon, size), LinearLayout.LayoutParams(size, size))
        if (showLabel) {
            col.addView(TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setShadowLayer(3f, 0f, 1f, Color.argb(120, 0, 0, 0))
                setPadding(2.dp, 6.dp, 2.dp, 0)
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        col.setOnClickListener { launch(app) }
        col.setOnLongClickListener { showMenu(col, app); true }
        col.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        return col
    }

    private fun iconView(d: Drawable, size: Int): ImageView = ImageView(this).apply {
        scaleType = ImageView.ScaleType.FIT_XY
        setImageDrawable(iosStyle(d, size))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                // iOS icon corner radius is ~22.37% of the icon width
                outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.2237f)
            }
        }
        clipToOutline = true
    }

    /** Draws adaptive icons as a full-bleed square (no circle/squircle mask) so we can round it iOS-style. */
    private fun iosStyle(d: Drawable, size: Int): Drawable {
        if (d is AdaptiveIconDrawable) {
            val layers = listOfNotNull(d.background, d.foreground).toTypedArray()
            val out = -(size * 0.25f).toInt() // layers are 108dp, visible area is the inner 72dp
            return LayerDrawable(layers).also { ld ->
                for (i in layers.indices) ld.setLayerInset(i, out, out, out, out)
            }
        }
        val pad = (size * 0.14f).toInt()
        return LayerDrawable(arrayOf(ColorDrawable(Color.WHITE), d)).also { it.setLayerInset(1, pad, pad, pad, pad) }
    }

    private fun launch(app: AppEntry) {
        try {
            startActivity(app.intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(anchor: View, app: AppEntry) {
        anchor.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        PopupMenu(this, anchor).apply {
            menu.add("App Info")
            menu.add("Remove App")
            setOnMenuItemClickListener { item ->
                val uri = Uri.parse("package:${app.pkg}")
                if (item.title.toString() == "App Info") {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                } else {
                    startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
                true
            }
            show()
        }
    }

    // ---------- Search ----------

    private fun openSearch() {
        overlay.visibility = View.VISIBLE
        searchField.requestFocus()
        WindowCompat.getInsetsController(window, searchField).show(WindowInsetsCompat.Type.ime())
    }

    private fun closeSearch() {
        searchField.setText("")
        searchField.clearFocus()
        overlay.visibility = View.GONE
        WindowCompat.getInsetsController(window, searchField).hide(WindowInsetsCompat.Type.ime())
    }

    private fun showResults(query: String) {
        results.removeAllViews()
        val q = query.trim()
        if (q.isEmpty()) return
        allApps.filter { it.label.contains(q, ignoreCase = true) }.take(8).forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8.dp, 8.dp, 8.dp, 8.dp)
                setOnClickListener { closeSearch(); launch(app) }
            }
            row.addView(iconView(app.icon, 44.dp), LinearLayout.LayoutParams(44.dp, 44.dp))
            row.addView(TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 17f
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = 14.dp })
            results.addView(row)
        }
    }

    // ---------- Data ----------

    private fun reload() {
        thread {
            val pm = packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(launcherIntent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val ai = ri.activityInfo
                    AppEntry(
                        ri.loadLabel(pm).toString(),
                        ai.packageName,
                        Intent(launcherIntent)
                            .setComponent(ComponentName(ai.packageName, ai.name))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                        ri.loadIcon(pm)
                    )
                }
            val dockApps = dockIntents.mapNotNull { base ->
                pm.queryIntentActivities(base, 0).firstOrNull()?.let { ri ->
                    val ai = ri.activityInfo
                    AppEntry(
                        ri.loadLabel(pm).toString(),
                        ai.packageName,
                        Intent(base).setClassName(ai.packageName, ai.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        ri.loadIcon(pm)
                    )
                }
            }.distinctBy { it.pkg }
            runOnUiThread { if (!isDestroyed) applyData(apps, dockApps) }
        }
    }

    private fun applyData(apps: List<AppEntry>, dockApps: List<AppEntry>) {
        val dockPkgs = dockApps.map { it.pkg }.toSet()
        val grid = apps.filter { it.pkg !in dockPkgs }.sortedBy { it.label.lowercase() }
        allApps = (grid + dockApps).sortedBy { it.label.lowercase() }

        val rows = rowsPerPage()
        val firstPageCapacity = COLS * (rows - 2).coerceAtLeast(1) // first page leaves room for the clock widget
        pages = listOf(grid.take(firstPageCapacity)) + grid.drop(firstPageCapacity).chunked(COLS * rows)
        pager.adapter?.notifyDataSetChanged()
        rebuildDots()

        dock.removeAllViews()
        dockApps.forEach { dock.addView(cell(it, showLabel = false), LinearLayout.LayoutParams(0, WRAP, 1f)) }
    }
}
